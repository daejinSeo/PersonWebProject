const myName = 'Max';

if (myName === 'Max') {
  console.log('Hello!');
}

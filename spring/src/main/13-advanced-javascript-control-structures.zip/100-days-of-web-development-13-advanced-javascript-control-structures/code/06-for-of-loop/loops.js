for (let i = 0; i < 10; i++) {
  console.log(i);
}

const users = ['Max', 'Anna', 'Joel'];

for (const user of users) {
  console.log(user);
}